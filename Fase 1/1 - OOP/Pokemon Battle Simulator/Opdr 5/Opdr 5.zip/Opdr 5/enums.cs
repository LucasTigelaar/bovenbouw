﻿namespace Pokemon_Battle_Simulator;

public enum PokemonTypes
{
    FIRE,
    GRASS,
    WATER,
}